
package bookpractice;

import java.util.Scanner;

/**
 *
 * @author asnopek
 */
public class BookPractice {

    public static void main(String[] args) {

        
        //Question One
        int age = 32;
        String name = "Abby";
        Double annualPay = 300.00;
        
        System.out.println("My name is " + name + " , my age is " + age + " and I hope to earn " + annualPay + " per year." );
        
        //Question Two
        String firstName = "Abby ";
        String middleName = "Lynette ";
        String lastName = "Snopek";
        
        System.out.println(firstName + middleName + lastName);
        
        //Question Three
        Scanner keyboard = new Scanner(System.in);
        
        System.out.println("What is your name? ");
        String inputName = keyboard.nextLine();
        
        System.out.println("What is your address? Include your city, state, and zip: ");
        String inputAddress = keyboard.nextLine();
        
        System.out.println("What is your telephone number? ");
        String inputPhoneNumber = keyboard.nextLine();
        
        System.out.println("What is your college major? ");
        String collegeMajor = keyboard.nextLine();
        
        System.out.println(inputName);
        System.out.println(inputAddress);
        System.out.println(inputPhoneNumber);
        System.out.println(collegeMajor);
        
        //Question Four
        System.out.println("   *   ");
        System.out.println("  ***  ");
        System.out.println(" ***** ");
        System.out.println("*******");
        System.out.println(" ***** ");
        System.out.println("  ***  ");
        System.out.println("   *   ");
        
        //Question Five
        double totalSales;
        double eastCoastSales;
        double percentageSales;
        
        System.out.println("What is the total sales for the year? ");
        totalSales = keyboard.nextDouble();
        
        System.out.println("What is the percentage of sales by the sale division? ");
        percentageSales = keyboard.nextDouble();
        
        eastCoastSales = totalSales * percentageSales;
        
        System.out.println("Total sales produced by the Sales Division in one year: ");
        System.out.println(eastCoastSales);
       
        //Question Six
        final double acre = 43560;
        double tractLand;
        double numberOfAcres;
        
        System.out.println("How big is your property in square feet: ");
        tractLand = keyboard.nextDouble();
        
        numberOfAcres = tractLand / acre;
        
        System.out.println("Your propety is " + numberOfAcres + " number of Acres.");
        
//Question Seven
        double amountOfPurchase;
        double stateTax = .04;
        double countyTax = .02;
        double amountState;
        double amountCounty;
        double totalSalesTax;
        double finalTotal;
        
        System.out.println("How much was your purchase: ");
        amountOfPurchase = keyboard.nextDouble();
        
        amountState = amountOfPurchase * stateTax;
        amountCounty = amountOfPurchase * countyTax;
        totalSalesTax = amountState + amountCounty;
        finalTotal = amountState + amountCounty + totalSalesTax;
        
        System.out.println("Your puchase amount: $" + amountOfPurchase);
        System.out.println("Your State Tax Amount: $" + amountState);
        System.out.println("Your County Tax Amount: $" + amountCounty);
        System.out.println("Your Total Sales Tax Amount: $" + totalSalesTax);
        System.out.println("Your Final Total including all taxes: $" + finalTotal);

       
      
        
        
        
        
        
        
        
    }
    
}
